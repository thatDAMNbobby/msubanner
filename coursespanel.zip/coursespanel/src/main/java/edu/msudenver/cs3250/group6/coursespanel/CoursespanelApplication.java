package edu.msudenver.cs3250.group6.coursespanel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursespanelApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursespanelApplication.class, args);
	}
}
